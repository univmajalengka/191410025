**Led_style**
Controler with Visual Studio,,

Codingan Yang Terdapat Di Ino(Arduino) adalah Hanya Diambil Basicnya saja,,
Semua Control Terdapat Pada Program Aplikasi Visual Studio (EXE)..

Seperti Biasa,, Semua Tombol dapat Berfungsi Hanya Ketika Serial Terkoneksi..