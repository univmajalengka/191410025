Jika Ada Keterangan Koneksi Gagal,, Maka Re Connect Kembali..

Note..
--> Aplikasi Ini Hanya Jalan Apabila Kita Telah Instal Arduino Ide,,
Atau Dengan Driver untuk Portnya yaitu "IC driver CH340"..

--> Untuk Keamanan Koneksi Serial Port,, Disengaja Program Akan Jalan
Ketika Selesai Koneksi Atau Port telah Terkoneksi,,

