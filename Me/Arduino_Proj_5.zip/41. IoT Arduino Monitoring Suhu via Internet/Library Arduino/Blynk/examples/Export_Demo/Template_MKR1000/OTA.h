/*
 * OTA is not ready for this board yet.
 * It could be derived from:
 * https://www.hackster.io/flower-platform/program-mkr-over-the-air-goodies-voice-control-etc-562e9a
 */

void enterOTA() {
  BlynkState::set(MODE_ERROR);
}

