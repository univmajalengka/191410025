﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GunaVProgressBar1 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar2 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar3 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar4 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar5 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar6 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaVProgressBar7 = New Guna.UI.WinForms.GunaVProgressBar()
        Me.GunaCircleProgressBar1 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar2 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar3 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar4 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar5 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar6 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar7 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GunaButton1 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton2 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton3 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton4 = New Guna.UI.WinForms.GunaButton()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Location = New System.Drawing.Point(-3, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(875, 59)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SkyBlue
        Me.Panel2.Controls.Add(Me.GunaButton4)
        Me.Panel2.Location = New System.Drawing.Point(-3, 481)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(875, 68)
        Me.Panel2.TabIndex = 1
        '
        'GunaVProgressBar1
        '
        Me.GunaVProgressBar1.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar1.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar1.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar1.Location = New System.Drawing.Point(63, 81)
        Me.GunaVProgressBar1.Name = "GunaVProgressBar1"
        Me.GunaVProgressBar1.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar1.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar1.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar1.TabIndex = 2
        Me.GunaVProgressBar1.Value = 30
        '
        'GunaVProgressBar2
        '
        Me.GunaVProgressBar2.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar2.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar2.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar2.Location = New System.Drawing.Point(129, 81)
        Me.GunaVProgressBar2.Name = "GunaVProgressBar2"
        Me.GunaVProgressBar2.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar2.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar2.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar2.TabIndex = 3
        Me.GunaVProgressBar2.Value = 30
        '
        'GunaVProgressBar3
        '
        Me.GunaVProgressBar3.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar3.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar3.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar3.Location = New System.Drawing.Point(193, 81)
        Me.GunaVProgressBar3.Name = "GunaVProgressBar3"
        Me.GunaVProgressBar3.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar3.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar3.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar3.TabIndex = 4
        Me.GunaVProgressBar3.Value = 30
        '
        'GunaVProgressBar4
        '
        Me.GunaVProgressBar4.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar4.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar4.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar4.Location = New System.Drawing.Point(257, 81)
        Me.GunaVProgressBar4.Name = "GunaVProgressBar4"
        Me.GunaVProgressBar4.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar4.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar4.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar4.TabIndex = 5
        Me.GunaVProgressBar4.Value = 30
        '
        'GunaVProgressBar5
        '
        Me.GunaVProgressBar5.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar5.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar5.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar5.Location = New System.Drawing.Point(322, 81)
        Me.GunaVProgressBar5.Name = "GunaVProgressBar5"
        Me.GunaVProgressBar5.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar5.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar5.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar5.TabIndex = 6
        Me.GunaVProgressBar5.Value = 30
        '
        'GunaVProgressBar6
        '
        Me.GunaVProgressBar6.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar6.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar6.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar6.Location = New System.Drawing.Point(396, 81)
        Me.GunaVProgressBar6.Name = "GunaVProgressBar6"
        Me.GunaVProgressBar6.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar6.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar6.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar6.TabIndex = 7
        Me.GunaVProgressBar6.Value = 30
        '
        'GunaVProgressBar7
        '
        Me.GunaVProgressBar7.BorderColor = System.Drawing.Color.Black
        Me.GunaVProgressBar7.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaVProgressBar7.IdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GunaVProgressBar7.Location = New System.Drawing.Point(474, 81)
        Me.GunaVProgressBar7.Name = "GunaVProgressBar7"
        Me.GunaVProgressBar7.ProgressMaxColor = System.Drawing.Color.Cyan
        Me.GunaVProgressBar7.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaVProgressBar7.Size = New System.Drawing.Size(30, 301)
        Me.GunaVProgressBar7.TabIndex = 8
        Me.GunaVProgressBar7.Value = 30
        '
        'GunaCircleProgressBar1
        '
        Me.GunaCircleProgressBar1.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar1.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar1.IdleOffset = 8
        Me.GunaCircleProgressBar1.IdleThickness = 8
        Me.GunaCircleProgressBar1.Image = Nothing
        Me.GunaCircleProgressBar1.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar1.Location = New System.Drawing.Point(53, 402)
        Me.GunaCircleProgressBar1.Name = "GunaCircleProgressBar1"
        Me.GunaCircleProgressBar1.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar1.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar1.ProgressOffset = 8
        Me.GunaCircleProgressBar1.ProgressThickness = 8
        Me.GunaCircleProgressBar1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar1.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar1.TabIndex = 9
        Me.GunaCircleProgressBar1.Value = 60
        '
        'GunaCircleProgressBar2
        '
        Me.GunaCircleProgressBar2.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar2.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar2.IdleOffset = 8
        Me.GunaCircleProgressBar2.IdleThickness = 8
        Me.GunaCircleProgressBar2.Image = Nothing
        Me.GunaCircleProgressBar2.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar2.Location = New System.Drawing.Point(118, 402)
        Me.GunaCircleProgressBar2.Name = "GunaCircleProgressBar2"
        Me.GunaCircleProgressBar2.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar2.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar2.ProgressOffset = 8
        Me.GunaCircleProgressBar2.ProgressThickness = 8
        Me.GunaCircleProgressBar2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar2.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar2.TabIndex = 10
        Me.GunaCircleProgressBar2.Value = 60
        '
        'GunaCircleProgressBar3
        '
        Me.GunaCircleProgressBar3.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar3.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar3.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar3.IdleOffset = 8
        Me.GunaCircleProgressBar3.IdleThickness = 8
        Me.GunaCircleProgressBar3.Image = Nothing
        Me.GunaCircleProgressBar3.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar3.Location = New System.Drawing.Point(185, 402)
        Me.GunaCircleProgressBar3.Name = "GunaCircleProgressBar3"
        Me.GunaCircleProgressBar3.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar3.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar3.ProgressOffset = 8
        Me.GunaCircleProgressBar3.ProgressThickness = 8
        Me.GunaCircleProgressBar3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar3.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar3.TabIndex = 11
        Me.GunaCircleProgressBar3.Value = 60
        '
        'GunaCircleProgressBar4
        '
        Me.GunaCircleProgressBar4.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar4.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar4.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar4.IdleOffset = 8
        Me.GunaCircleProgressBar4.IdleThickness = 8
        Me.GunaCircleProgressBar4.Image = Nothing
        Me.GunaCircleProgressBar4.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar4.Location = New System.Drawing.Point(247, 402)
        Me.GunaCircleProgressBar4.Name = "GunaCircleProgressBar4"
        Me.GunaCircleProgressBar4.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar4.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar4.ProgressOffset = 8
        Me.GunaCircleProgressBar4.ProgressThickness = 8
        Me.GunaCircleProgressBar4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar4.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar4.TabIndex = 12
        Me.GunaCircleProgressBar4.Value = 60
        '
        'GunaCircleProgressBar5
        '
        Me.GunaCircleProgressBar5.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar5.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar5.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar5.IdleOffset = 8
        Me.GunaCircleProgressBar5.IdleThickness = 8
        Me.GunaCircleProgressBar5.Image = Nothing
        Me.GunaCircleProgressBar5.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar5.Location = New System.Drawing.Point(315, 402)
        Me.GunaCircleProgressBar5.Name = "GunaCircleProgressBar5"
        Me.GunaCircleProgressBar5.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar5.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar5.ProgressOffset = 8
        Me.GunaCircleProgressBar5.ProgressThickness = 8
        Me.GunaCircleProgressBar5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar5.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar5.TabIndex = 13
        Me.GunaCircleProgressBar5.Value = 60
        '
        'GunaCircleProgressBar6
        '
        Me.GunaCircleProgressBar6.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar6.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar6.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar6.IdleOffset = 8
        Me.GunaCircleProgressBar6.IdleThickness = 8
        Me.GunaCircleProgressBar6.Image = Nothing
        Me.GunaCircleProgressBar6.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar6.Location = New System.Drawing.Point(387, 402)
        Me.GunaCircleProgressBar6.Name = "GunaCircleProgressBar6"
        Me.GunaCircleProgressBar6.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar6.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar6.ProgressOffset = 8
        Me.GunaCircleProgressBar6.ProgressThickness = 8
        Me.GunaCircleProgressBar6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar6.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar6.TabIndex = 14
        Me.GunaCircleProgressBar6.Value = 60
        '
        'GunaCircleProgressBar7
        '
        Me.GunaCircleProgressBar7.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar7.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBar7.IdleColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar7.IdleOffset = 8
        Me.GunaCircleProgressBar7.IdleThickness = 8
        Me.GunaCircleProgressBar7.Image = Nothing
        Me.GunaCircleProgressBar7.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar7.Location = New System.Drawing.Point(465, 402)
        Me.GunaCircleProgressBar7.Name = "GunaCircleProgressBar7"
        Me.GunaCircleProgressBar7.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar7.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBar7.ProgressOffset = 8
        Me.GunaCircleProgressBar7.ProgressThickness = 8
        Me.GunaCircleProgressBar7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GunaCircleProgressBar7.Size = New System.Drawing.Size(51, 50)
        Me.GunaCircleProgressBar7.TabIndex = 15
        Me.GunaCircleProgressBar7.Value = 60
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.VScrollBar1.Location = New System.Drawing.Point(561, 81)
        Me.VScrollBar1.Maximum = 210
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(34, 371)
        Me.VScrollBar1.TabIndex = 16
        Me.VScrollBar1.Value = 210
        '
        'Timer1
        '
        Me.Timer1.Interval = 250
        '
        'GunaButton1
        '
        Me.GunaButton1.AnimationHoverSpeed = 0.07!
        Me.GunaButton1.AnimationSpeed = 0.03!
        Me.GunaButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton1.ForeColor = System.Drawing.Color.White
        Me.GunaButton1.Image = CType(resources.GetObject("GunaButton1.Image"), System.Drawing.Image)
        Me.GunaButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton1.Location = New System.Drawing.Point(678, 81)
        Me.GunaButton1.Name = "GunaButton1"
        Me.GunaButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton1.OnHoverImage = Nothing
        Me.GunaButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton1.Size = New System.Drawing.Size(149, 48)
        Me.GunaButton1.TabIndex = 17
        Me.GunaButton1.Text = "Start"
        Me.GunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaButton2
        '
        Me.GunaButton2.AnimationHoverSpeed = 0.07!
        Me.GunaButton2.AnimationSpeed = 0.03!
        Me.GunaButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GunaButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton2.ForeColor = System.Drawing.Color.White
        Me.GunaButton2.Image = CType(resources.GetObject("GunaButton2.Image"), System.Drawing.Image)
        Me.GunaButton2.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton2.Location = New System.Drawing.Point(678, 135)
        Me.GunaButton2.Name = "GunaButton2"
        Me.GunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton2.OnHoverImage = Nothing
        Me.GunaButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton2.Size = New System.Drawing.Size(149, 48)
        Me.GunaButton2.TabIndex = 18
        Me.GunaButton2.Text = "Stop"
        Me.GunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaButton3
        '
        Me.GunaButton3.AnimationHoverSpeed = 0.07!
        Me.GunaButton3.AnimationSpeed = 0.03!
        Me.GunaButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton3.ForeColor = System.Drawing.Color.White
        Me.GunaButton3.Image = CType(resources.GetObject("GunaButton3.Image"), System.Drawing.Image)
        Me.GunaButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton3.Location = New System.Drawing.Point(678, 189)
        Me.GunaButton3.Name = "GunaButton3"
        Me.GunaButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton3.OnHoverImage = Nothing
        Me.GunaButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton3.Size = New System.Drawing.Size(149, 48)
        Me.GunaButton3.TabIndex = 19
        Me.GunaButton3.Text = "Reset"
        Me.GunaButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaButton4
        '
        Me.GunaButton4.AnimationHoverSpeed = 0.07!
        Me.GunaButton4.AnimationSpeed = 0.03!
        Me.GunaButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GunaButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton4.ForeColor = System.Drawing.Color.White
        Me.GunaButton4.Image = CType(resources.GetObject("GunaButton4.Image"), System.Drawing.Image)
        Me.GunaButton4.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton4.Location = New System.Drawing.Point(724, 9)
        Me.GunaButton4.Name = "GunaButton4"
        Me.GunaButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton4.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton4.OnHoverImage = Nothing
        Me.GunaButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton4.Size = New System.Drawing.Size(106, 48)
        Me.GunaButton4.TabIndex = 20
        Me.GunaButton4.Text = "Keluar"
        Me.GunaButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(871, 548)
        Me.Controls.Add(Me.GunaButton3)
        Me.Controls.Add(Me.GunaButton2)
        Me.Controls.Add(Me.GunaButton1)
        Me.Controls.Add(Me.VScrollBar1)
        Me.Controls.Add(Me.GunaCircleProgressBar7)
        Me.Controls.Add(Me.GunaCircleProgressBar6)
        Me.Controls.Add(Me.GunaCircleProgressBar5)
        Me.Controls.Add(Me.GunaCircleProgressBar4)
        Me.Controls.Add(Me.GunaCircleProgressBar3)
        Me.Controls.Add(Me.GunaCircleProgressBar2)
        Me.Controls.Add(Me.GunaCircleProgressBar1)
        Me.Controls.Add(Me.GunaVProgressBar7)
        Me.Controls.Add(Me.GunaVProgressBar6)
        Me.Controls.Add(Me.GunaVProgressBar5)
        Me.Controls.Add(Me.GunaVProgressBar4)
        Me.Controls.Add(Me.GunaVProgressBar3)
        Me.Controls.Add(Me.GunaVProgressBar2)
        Me.Controls.Add(Me.GunaVProgressBar1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents GunaVProgressBar1 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar2 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar3 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar4 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar5 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar6 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaVProgressBar7 As Guna.UI.WinForms.GunaVProgressBar
    Friend WithEvents GunaCircleProgressBar1 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar2 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar3 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar4 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar5 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar6 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar7 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents VScrollBar1 As System.Windows.Forms.VScrollBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents GunaButton1 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton2 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton4 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton3 As Guna.UI.WinForms.GunaButton

End Class
