﻿Public Class Form1
    Dim interval As Integer = -50
    Dim ResInterval As Integer
    Dim detik As Integer
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub VScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles VScrollBar1.Scroll
        ResInterval = VScrollBar1.Value - interval
        Timer1.Interval = ResInterval
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        detik += 1
        If detik = 1 Then
            GunaCircleProgressBar1.Value = 10
            GunaCircleProgressBar2.Value = 60
            GunaCircleProgressBar3.Value = 40
            GunaCircleProgressBar4.Value = 50
            GunaCircleProgressBar5.Value = 80
            GunaCircleProgressBar6.Value = 30
            GunaCircleProgressBar7.Value = 20
            GunaVProgressBar1.Value = 10
            GunaVProgressBar2.Value = 60
            GunaVProgressBar3.Value = 40
            GunaVProgressBar4.Value = 50
            GunaVProgressBar5.Value = 80
            GunaVProgressBar6.Value = 30
            GunaVProgressBar7.Value = 20
        ElseIf detik = 2 Then
            GunaCircleProgressBar1.Value = 50
            GunaCircleProgressBar2.Value = 20
            GunaCircleProgressBar3.Value = 10
            GunaCircleProgressBar4.Value = 70
            GunaCircleProgressBar5.Value = 60
            GunaCircleProgressBar6.Value = 80
            GunaCircleProgressBar7.Value = 10
            GunaVProgressBar1.Value = 50
            GunaVProgressBar2.Value = 20
            GunaVProgressBar3.Value = 10
            GunaVProgressBar4.Value = 70
            GunaVProgressBar5.Value = 60
            GunaVProgressBar6.Value = 80
            GunaVProgressBar7.Value = 10
        ElseIf detik = 3 Then
            GunaCircleProgressBar1.Value = 90
            GunaCircleProgressBar2.Value = 30
            GunaCircleProgressBar3.Value = 70
            GunaCircleProgressBar4.Value = 20
            GunaCircleProgressBar5.Value = 10
            GunaCircleProgressBar6.Value = 60
            GunaCircleProgressBar7.Value = 50
            GunaVProgressBar1.Value = 90
            GunaVProgressBar2.Value = 30
            GunaVProgressBar3.Value = 70
            GunaVProgressBar4.Value = 20
            GunaVProgressBar5.Value = 10
            GunaVProgressBar6.Value = 60
            GunaVProgressBar7.Value = 50
        ElseIf detik = 4 Then
            GunaCircleProgressBar1.Value = 30
            GunaCircleProgressBar2.Value = 50
            GunaCircleProgressBar3.Value = 10
            GunaCircleProgressBar4.Value = 90
            GunaCircleProgressBar5.Value = 40
            GunaCircleProgressBar6.Value = 20
            GunaCircleProgressBar7.Value = 80
            GunaVProgressBar1.Value = 30
            GunaVProgressBar2.Value = 50
            GunaVProgressBar3.Value = 10
            GunaVProgressBar4.Value = 90
            GunaVProgressBar5.Value = 40
            GunaVProgressBar6.Value = 20
            GunaVProgressBar7.Value = 80
            detik = 0
        End If
    End Sub

    Private Sub GunaButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Timer1.Start()
    End Sub

    Private Sub GunaButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton2.Click
        Timer1.Stop()
    End Sub

    Private Sub GunaButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Timer1.Stop()
        VScrollBar1.Value = 200
        GunaCircleProgressBar1.Value = 60
        GunaCircleProgressBar2.Value = 60
        GunaCircleProgressBar3.Value = 60
        GunaCircleProgressBar4.Value = 60
        GunaCircleProgressBar5.Value = 60
        GunaCircleProgressBar6.Value = 60
        GunaCircleProgressBar7.Value = 60
        GunaVProgressBar1.Value = 30
        GunaVProgressBar2.Value = 30
        GunaVProgressBar3.Value = 30
        GunaVProgressBar4.Value = 30
        GunaVProgressBar5.Value = 30
        GunaVProgressBar6.Value = 30
        GunaVProgressBar7.Value = 30
        detik = 0
    End Sub

    Private Sub GunaButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton4.Click
        Try
            Timer1.Stop()
            Me.Close()
            End
        Catch ex As Exception
            Timer1.Stop()
            Me.Close()
        End Try
    End Sub
End Class
