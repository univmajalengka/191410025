﻿Public Class Form1
    Dim interval As Integer = 1100
    Dim resInterval As Integer
    Dim detik, menit, jam As Integer
    Private Sub GunaHScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles GunaHScrollBar1.Scroll
        resInterval = interval - GunaHScrollBar1.Value
        Label1.Text = resInterval
        Timer1.Interval = resInterval
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        detik += 1
        GunaCircleProgressBarDetik.Value = detik
        LabelDetik.Text = detik
        GunaCircleProgressBarMenit.Value = menit
        LabelMenit.Text = menit
        GunaCircleProgressBarJam.Value = jam
        LabelJam.Text = jam
        If detik = 60 Then
            menit += 1
            detik = 0
        ElseIf menit = 60 Then
            jam += 1
            menit = 0
        ElseIf jam = 24 Then
            jam = 0
            menit = 0
            detik = 0
        End If
    End Sub

    Private Sub GunaAdvenceButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaAdvenceButton1.Click
        Timer1.Start()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Interval = 1000
    End Sub

    Private Sub GunaAdvenceButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaAdvenceButton3.Click
        Timer1.Stop()
        Me.Close()
    End Sub

    Private Sub GunaAdvenceButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaAdvenceButton4.Click
        Timer1.Stop()
        detik = 0
        menit = 0
        jam = 0
        LabelDetik.Text = 0
        LabelMenit.Text = 0
        LabelJam.Text = 0
        GunaCircleProgressBarDetik.Value = 0
        GunaCircleProgressBarMenit.Value = 0
        GunaCircleProgressBarJam.Value = 0
        GunaHScrollBar1.Value = 100
    End Sub

    Private Sub GunaAdvenceButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaAdvenceButton2.Click
        Timer1.Stop()
    End Sub
End Class
