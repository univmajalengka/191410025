﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GunaCircleProgressBarDetik = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBarMenit = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBarJam = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaHScrollBar1 = New Guna.UI.WinForms.GunaHScrollBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.LabelDetik = New System.Windows.Forms.Label()
        Me.LabelMenit = New System.Windows.Forms.Label()
        Me.LabelJam = New System.Windows.Forms.Label()
        Me.GunaAdvenceButton2 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceButton3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceButton4 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Panel2.SuspendLayout()
        Me.GunaCircleProgressBarDetik.SuspendLayout()
        Me.GunaCircleProgressBarMenit.SuspendLayout()
        Me.GunaCircleProgressBarJam.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1100
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Location = New System.Drawing.Point(-1, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(804, 62)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightBlue
        Me.Panel2.Controls.Add(Me.GunaAdvenceButton4)
        Me.Panel2.Controls.Add(Me.GunaAdvenceButton3)
        Me.Panel2.Location = New System.Drawing.Point(-2, 531)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(804, 70)
        Me.Panel2.TabIndex = 1
        '
        'GunaCircleProgressBarDetik
        '
        Me.GunaCircleProgressBarDetik.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBarDetik.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBarDetik.Controls.Add(Me.LabelDetik)
        Me.GunaCircleProgressBarDetik.IdleColor = System.Drawing.Color.White
        Me.GunaCircleProgressBarDetik.IdleOffset = 20
        Me.GunaCircleProgressBarDetik.Image = Nothing
        Me.GunaCircleProgressBarDetik.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBarDetik.Location = New System.Drawing.Point(538, 95)
        Me.GunaCircleProgressBarDetik.Maximum = 60
        Me.GunaCircleProgressBarDetik.Name = "GunaCircleProgressBarDetik"
        Me.GunaCircleProgressBarDetik.ProgressMaxColor = System.Drawing.Color.Aqua
        Me.GunaCircleProgressBarDetik.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBarDetik.ProgressOffset = 20
        Me.GunaCircleProgressBarDetik.Size = New System.Drawing.Size(202, 202)
        Me.GunaCircleProgressBarDetik.TabIndex = 2
        '
        'GunaCircleProgressBarMenit
        '
        Me.GunaCircleProgressBarMenit.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBarMenit.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBarMenit.Controls.Add(Me.LabelMenit)
        Me.GunaCircleProgressBarMenit.IdleColor = System.Drawing.Color.White
        Me.GunaCircleProgressBarMenit.IdleOffset = 20
        Me.GunaCircleProgressBarMenit.Image = Nothing
        Me.GunaCircleProgressBarMenit.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBarMenit.Location = New System.Drawing.Point(306, 95)
        Me.GunaCircleProgressBarMenit.Maximum = 60
        Me.GunaCircleProgressBarMenit.Name = "GunaCircleProgressBarMenit"
        Me.GunaCircleProgressBarMenit.ProgressMaxColor = System.Drawing.Color.Fuchsia
        Me.GunaCircleProgressBarMenit.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBarMenit.ProgressOffset = 20
        Me.GunaCircleProgressBarMenit.Size = New System.Drawing.Size(202, 202)
        Me.GunaCircleProgressBarMenit.TabIndex = 3
        '
        'GunaCircleProgressBarJam
        '
        Me.GunaCircleProgressBarJam.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBarJam.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleProgressBarJam.Controls.Add(Me.LabelJam)
        Me.GunaCircleProgressBarJam.IdleColor = System.Drawing.Color.White
        Me.GunaCircleProgressBarJam.IdleOffset = 20
        Me.GunaCircleProgressBarJam.Image = Nothing
        Me.GunaCircleProgressBarJam.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBarJam.Location = New System.Drawing.Point(68, 95)
        Me.GunaCircleProgressBarJam.Maximum = 24
        Me.GunaCircleProgressBarJam.Name = "GunaCircleProgressBarJam"
        Me.GunaCircleProgressBarJam.ProgressMaxColor = System.Drawing.Color.Blue
        Me.GunaCircleProgressBarJam.ProgressMinColor = System.Drawing.Color.Yellow
        Me.GunaCircleProgressBarJam.ProgressOffset = 20
        Me.GunaCircleProgressBarJam.Size = New System.Drawing.Size(202, 202)
        Me.GunaCircleProgressBarJam.TabIndex = 4
        '
        'GunaHScrollBar1
        '
        Me.GunaHScrollBar1.BackColor = System.Drawing.Color.Transparent
        Me.GunaHScrollBar1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaHScrollBar1.LargeChange = 10
        Me.GunaHScrollBar1.Location = New System.Drawing.Point(68, 317)
        Me.GunaHScrollBar1.Maximum = 1050
        Me.GunaHScrollBar1.Minimum = 100
        Me.GunaHScrollBar1.Name = "GunaHScrollBar1"
        Me.GunaHScrollBar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GunaHScrollBar1.ScrollIdleColor = System.Drawing.Color.Silver
        Me.GunaHScrollBar1.Size = New System.Drawing.Size(671, 43)
        Me.GunaHScrollBar1.TabIndex = 6
        Me.GunaHScrollBar1.ThumbColor = System.Drawing.Color.DimGray
        Me.GunaHScrollBar1.ThumbHoverColor = System.Drawing.Color.Gray
        Me.GunaHScrollBar1.ThumbPressedColor = System.Drawing.Color.DarkGray
        Me.GunaHScrollBar1.Value = 100
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(335, 363)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 23)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Interval"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.Image = Nothing
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(335, 394)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.OnHoverImage = Nothing
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(133, 51)
        Me.GunaAdvenceButton1.TabIndex = 8
        Me.GunaAdvenceButton1.Text = "Start_Timer"
        Me.GunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabelDetik
        '
        Me.LabelDetik.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelDetik.ForeColor = System.Drawing.Color.White
        Me.LabelDetik.Location = New System.Drawing.Point(61, 77)
        Me.LabelDetik.Name = "LabelDetik"
        Me.LabelDetik.Size = New System.Drawing.Size(82, 51)
        Me.LabelDetik.TabIndex = 9
        Me.LabelDetik.Text = "0"
        Me.LabelDetik.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelMenit
        '
        Me.LabelMenit.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMenit.ForeColor = System.Drawing.Color.White
        Me.LabelMenit.Location = New System.Drawing.Point(60, 76)
        Me.LabelMenit.Name = "LabelMenit"
        Me.LabelMenit.Size = New System.Drawing.Size(82, 51)
        Me.LabelMenit.TabIndex = 10
        Me.LabelMenit.Text = "0"
        Me.LabelMenit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelJam
        '
        Me.LabelJam.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelJam.ForeColor = System.Drawing.Color.White
        Me.LabelJam.Location = New System.Drawing.Point(60, 76)
        Me.LabelJam.Name = "LabelJam"
        Me.LabelJam.Size = New System.Drawing.Size(82, 51)
        Me.LabelJam.TabIndex = 10
        Me.LabelJam.Text = "0"
        Me.LabelJam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GunaAdvenceButton2
        '
        Me.GunaAdvenceButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GunaAdvenceButton2.Image = Nothing
        Me.GunaAdvenceButton2.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.Location = New System.Drawing.Point(374, 451)
        Me.GunaAdvenceButton2.Name = "GunaAdvenceButton2"
        Me.GunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.OnHoverImage = Nothing
        Me.GunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.Size = New System.Drawing.Size(59, 40)
        Me.GunaAdvenceButton2.TabIndex = 9
        Me.GunaAdvenceButton2.Text = "Stop"
        Me.GunaAdvenceButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaAdvenceButton3
        '
        Me.GunaAdvenceButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton3.ForeColor = System.Drawing.Color.Maroon
        Me.GunaAdvenceButton3.Image = Nothing
        Me.GunaAdvenceButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.Location = New System.Drawing.Point(648, 19)
        Me.GunaAdvenceButton3.Name = "GunaAdvenceButton3"
        Me.GunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.OnHoverImage = Nothing
        Me.GunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.Size = New System.Drawing.Size(94, 35)
        Me.GunaAdvenceButton3.TabIndex = 10
        Me.GunaAdvenceButton3.Text = "Keluar"
        Me.GunaAdvenceButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaAdvenceButton4
        '
        Me.GunaAdvenceButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton4.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton4.ForeColor = System.Drawing.Color.Khaki
        Me.GunaAdvenceButton4.Image = Nothing
        Me.GunaAdvenceButton4.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton4.Location = New System.Drawing.Point(548, 19)
        Me.GunaAdvenceButton4.Name = "GunaAdvenceButton4"
        Me.GunaAdvenceButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaAdvenceButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton4.OnHoverImage = Nothing
        Me.GunaAdvenceButton4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.Size = New System.Drawing.Size(94, 35)
        Me.GunaAdvenceButton4.TabIndex = 11
        Me.GunaAdvenceButton4.Text = "Reset"
        Me.GunaAdvenceButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(800, 600)
        Me.Controls.Add(Me.GunaAdvenceButton2)
        Me.Controls.Add(Me.GunaAdvenceButton1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GunaHScrollBar1)
        Me.Controls.Add(Me.GunaCircleProgressBarJam)
        Me.Controls.Add(Me.GunaCircleProgressBarMenit)
        Me.Controls.Add(Me.GunaCircleProgressBarDetik)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel2.ResumeLayout(False)
        Me.GunaCircleProgressBarDetik.ResumeLayout(False)
        Me.GunaCircleProgressBarMenit.ResumeLayout(False)
        Me.GunaCircleProgressBarJam.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents GunaCircleProgressBarDetik As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBarMenit As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBarJam As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaHScrollBar1 As Guna.UI.WinForms.GunaHScrollBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents LabelDetik As System.Windows.Forms.Label
    Friend WithEvents LabelMenit As System.Windows.Forms.Label
    Friend WithEvents LabelJam As System.Windows.Forms.Label
    Friend WithEvents GunaAdvenceButton4 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton2 As Guna.UI.WinForms.GunaAdvenceButton

End Class
