Sebelum Kamu Menggunakan Guna_UI Winform,,
Kamu Harus Memmasangnya Dahulu Pada Toolbox yang ada PAda Visual Basic ToolBox..

Dengan Cara,,
-- > Klik Kanan Pada ToolBox lalu choose Items,,
-- > Tujukan Pada Folder yang Didalamnya Ada File "Guna_Ui.dll" nya.. Kalau Disini Yaitu
     Di Folder "Guna.UI_WinForms -- > .net4.0"