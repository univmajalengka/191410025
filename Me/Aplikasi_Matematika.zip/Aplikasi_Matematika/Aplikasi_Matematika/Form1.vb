﻿Public Class Form1

    Private Sub PanelLingkaran_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PanelLingkaran.Paint

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If TextBoxJari_Jari.Text = "" Then
            MsgBox("Isi Nilai Jari-Jari Terlebih Dahulu", MsgBoxStyle.Information, "Keterangan")
            TextBoxJari_Jari.Focus()
        Else
            TextBoxResLuas.Text = Val(LabelPhi.Text) * Val((TextBoxJari_Jari.Text) ^ 2)
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If TextBoxDiameter.Text = "" Then
            MsgBox("Isi Nilai Diamater Terlebih Dahulu", MsgBoxStyle.Information, "Keterangan")
            TextBoxDiameter.Focus()
        Else
            TextBoxResVolume.Text = Val(LabelPhi.Text) * Val(TextBoxDiameter.Text)
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        If TextBoxPanjang.Text = "" Or TextBoxLebar.Text = "" Then
            MsgBox("Isi Nilai Panjang dan Lebar" & vbNewLine & "Untuk Sesi Pengukuran Luas", MsgBoxStyle.Information, "Keterangtan")
            TextBoxPanjang.Focus()
        Else
            TextBoxLuasPerPan.Text = Val(TextBoxPanjang.Text) * Val(TextBoxLebar.Text)
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If TextBoxKelPan.Text = "" Or TextBoxKelLel.Text = "" Then
            MsgBox("Isi Nilai Panjang, Lebar dan Tinggi" & vbNewLine & "Untuk Sesi Pengukuran Volume", MsgBoxStyle.Information, "Keterangtan")
            TextBoxKelPan.Focus()
        Else
            TextBoxResKel.Text = Val((TextBoxKelPan.Text) * 2) + Val((TextBoxKelLel.Text) * 2)
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        If TextBoxAlas.Text = "" Or TextBoxTinggi.Text = "" Then
            MsgBox("Isi Nilai Alas dan Tinggi terlebih Dahulu", MsgBoxStyle.Information, "Keterangan")
        Else
            TextBoxLuasSegitiga.Text = Val((TextBoxAlas.Text) * Val(TextBoxTinggi.Text)) / 2
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBoxS1.Text = "" Or TextBoxS2.Text = "" Or TextBoxS3.Text = "" Then
            MsgBox("Isi Nilai sisi-sisi Segitiga terlebih Dahulu", MsgBoxStyle.Information, "Keterangan")
            TextBoxS1.Focus()
        Else
            TextBoxKllS.Text = Val(TextBoxS1.Text) + Val(TextBoxS2.Text) + Val(TextBoxS3.Text)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        PanelLingkaran.Visible = True
        PanelPersegi.Visible = False
        PanelSegitiga.Visible = False
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        PanelLingkaran.Visible = False
        PanelPersegi.Visible = True
        PanelSegitiga.Visible = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        PanelLingkaran.Visible = False
        PanelPersegi.Visible = False
        PanelSegitiga.Visible = True
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Me.Close()
        End
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Dim i As New Form1
        i.Show()
        Me.Hide()
    End Sub
End Class
