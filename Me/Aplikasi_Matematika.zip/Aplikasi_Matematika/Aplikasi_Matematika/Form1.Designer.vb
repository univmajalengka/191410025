﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.PanelLingkaran = New System.Windows.Forms.Panel()
        Me.TextBoxResVolume = New System.Windows.Forms.TextBox()
        Me.TextBoxResLuas = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TextBoxDiameter = New System.Windows.Forms.TextBox()
        Me.TextBoxJari_Jari = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LabelPhi = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelPersegi = New System.Windows.Forms.Panel()
        Me.TextBoxKelLel = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxLebar = New System.Windows.Forms.TextBox()
        Me.TextBoxLuasPerPan = New System.Windows.Forms.TextBox()
        Me.TextBoxResKel = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TextBoxPanjang = New System.Windows.Forms.TextBox()
        Me.TextBoxKelPan = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.PanelSegitiga = New System.Windows.Forms.Panel()
        Me.TextBoxS3 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBoxS2 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBoxTinggi = New System.Windows.Forms.TextBox()
        Me.TextBoxLuasSegitiga = New System.Windows.Forms.TextBox()
        Me.TextBoxKllS = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.TextBoxAlas = New System.Windows.Forms.TextBox()
        Me.TextBoxS1 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Panel2.SuspendLayout()
        Me.PanelLingkaran.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelPersegi.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelSegitiga.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(800, 66)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SkyBlue
        Me.Panel2.Controls.Add(Me.Button11)
        Me.Panel2.Controls.Add(Me.Button10)
        Me.Panel2.Location = New System.Drawing.Point(0, 529)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(800, 71)
        Me.Panel2.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Olive
        Me.Button1.Location = New System.Drawing.Point(518, 98)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(123, 68)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Hitung Lingkaran"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(647, 98)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(123, 68)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Hitung Persegi" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Panjang"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'PanelLingkaran
        '
        Me.PanelLingkaran.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PanelLingkaran.Controls.Add(Me.TextBoxResVolume)
        Me.PanelLingkaran.Controls.Add(Me.TextBoxResLuas)
        Me.PanelLingkaran.Controls.Add(Me.Button6)
        Me.PanelLingkaran.Controls.Add(Me.Button5)
        Me.PanelLingkaran.Controls.Add(Me.TextBoxDiameter)
        Me.PanelLingkaran.Controls.Add(Me.TextBoxJari_Jari)
        Me.PanelLingkaran.Controls.Add(Me.Label4)
        Me.PanelLingkaran.Controls.Add(Me.Label3)
        Me.PanelLingkaran.Controls.Add(Me.PictureBox1)
        Me.PanelLingkaran.Controls.Add(Me.LabelPhi)
        Me.PanelLingkaran.Controls.Add(Me.Label2)
        Me.PanelLingkaran.Controls.Add(Me.Label1)
        Me.PanelLingkaran.Location = New System.Drawing.Point(23, 94)
        Me.PanelLingkaran.Name = "PanelLingkaran"
        Me.PanelLingkaran.Size = New System.Drawing.Size(470, 409)
        Me.PanelLingkaran.TabIndex = 6
        '
        'TextBoxResVolume
        '
        Me.TextBoxResVolume.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResVolume.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxResVolume.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResVolume.Location = New System.Drawing.Point(217, 285)
        Me.TextBoxResVolume.Name = "TextBoxResVolume"
        Me.TextBoxResVolume.ReadOnly = True
        Me.TextBoxResVolume.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxResVolume.TabIndex = 11
        Me.TextBoxResVolume.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxResLuas
        '
        Me.TextBoxResLuas.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResLuas.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxResLuas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResLuas.Location = New System.Drawing.Point(345, 285)
        Me.TextBoxResLuas.Name = "TextBoxResLuas"
        Me.TextBoxResLuas.ReadOnly = True
        Me.TextBoxResLuas.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxResLuas.TabIndex = 10
        Me.TextBoxResLuas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(217, 216)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(95, 63)
        Me.Button6.TabIndex = 9
        Me.Button6.Text = "Volume"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Olive
        Me.Button5.Location = New System.Drawing.Point(345, 216)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(95, 63)
        Me.Button5.TabIndex = 8
        Me.Button5.Text = "Luas"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'TextBoxDiameter
        '
        Me.TextBoxDiameter.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxDiameter.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxDiameter.Location = New System.Drawing.Point(217, 181)
        Me.TextBoxDiameter.Name = "TextBoxDiameter"
        Me.TextBoxDiameter.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxDiameter.TabIndex = 7
        Me.TextBoxDiameter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxJari_Jari
        '
        Me.TextBoxJari_Jari.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxJari_Jari.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxJari_Jari.Location = New System.Drawing.Point(345, 181)
        Me.TextBoxJari_Jari.Name = "TextBoxJari_Jari"
        Me.TextBoxJari_Jari.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxJari_Jari.TabIndex = 6
        Me.TextBoxJari_Jari.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(219, 154)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 24)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Diameter"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(345, 154)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 24)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Jari - Jari"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(33, 160)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(152, 155)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'LabelPhi
        '
        Me.LabelPhi.AutoSize = True
        Me.LabelPhi.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelPhi.ForeColor = System.Drawing.Color.White
        Me.LabelPhi.Location = New System.Drawing.Point(255, 79)
        Me.LabelPhi.Name = "LabelPhi"
        Me.LabelPhi.Size = New System.Drawing.Size(49, 24)
        Me.LabelPhi.TabIndex = 2
        Me.LabelPhi.Text = "3.14"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(185, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Phi = "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(127, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(246, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Hitung Bangun Lingkaran"
        '
        'PanelPersegi
        '
        Me.PanelPersegi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PanelPersegi.Controls.Add(Me.TextBoxKelLel)
        Me.PanelPersegi.Controls.Add(Me.Label11)
        Me.PanelPersegi.Controls.Add(Me.Label10)
        Me.PanelPersegi.Controls.Add(Me.Label8)
        Me.PanelPersegi.Controls.Add(Me.Label7)
        Me.PanelPersegi.Controls.Add(Me.TextBoxLebar)
        Me.PanelPersegi.Controls.Add(Me.TextBoxLuasPerPan)
        Me.PanelPersegi.Controls.Add(Me.TextBoxResKel)
        Me.PanelPersegi.Controls.Add(Me.Button7)
        Me.PanelPersegi.Controls.Add(Me.Button8)
        Me.PanelPersegi.Controls.Add(Me.TextBoxPanjang)
        Me.PanelPersegi.Controls.Add(Me.TextBoxKelPan)
        Me.PanelPersegi.Controls.Add(Me.Label5)
        Me.PanelPersegi.Controls.Add(Me.Label6)
        Me.PanelPersegi.Controls.Add(Me.PictureBox2)
        Me.PanelPersegi.Controls.Add(Me.Label9)
        Me.PanelPersegi.Location = New System.Drawing.Point(23, 94)
        Me.PanelPersegi.Name = "PanelPersegi"
        Me.PanelPersegi.Size = New System.Drawing.Size(470, 409)
        Me.PanelPersegi.TabIndex = 12
        '
        'TextBoxKelLel
        '
        Me.TextBoxKelLel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxKelLel.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxKelLel.Location = New System.Drawing.Point(352, 190)
        Me.TextBoxKelLel.Name = "TextBoxKelLel"
        Me.TextBoxKelLel.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxKelLel.TabIndex = 17
        Me.TextBoxKelLel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(325, 191)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(21, 24)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "L"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(323, 156)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(23, 24)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "P"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(191, 188)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(21, 24)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "L"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(191, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(23, 24)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "P"
        '
        'TextBoxLebar
        '
        Me.TextBoxLebar.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxLebar.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxLebar.Location = New System.Drawing.Point(220, 188)
        Me.TextBoxLebar.Name = "TextBoxLebar"
        Me.TextBoxLebar.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxLebar.TabIndex = 12
        Me.TextBoxLebar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxLuasPerPan
        '
        Me.TextBoxLuasPerPan.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLuasPerPan.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxLuasPerPan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLuasPerPan.Location = New System.Drawing.Point(220, 292)
        Me.TextBoxLuasPerPan.Name = "TextBoxLuasPerPan"
        Me.TextBoxLuasPerPan.ReadOnly = True
        Me.TextBoxLuasPerPan.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxLuasPerPan.TabIndex = 11
        Me.TextBoxLuasPerPan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxResKel
        '
        Me.TextBoxResKel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResKel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxResKel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxResKel.Location = New System.Drawing.Point(352, 294)
        Me.TextBoxResKel.Name = "TextBoxResKel"
        Me.TextBoxResKel.ReadOnly = True
        Me.TextBoxResKel.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxResKel.TabIndex = 10
        Me.TextBoxResKel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button7.Location = New System.Drawing.Point(352, 225)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(95, 63)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "Keliling"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.ForeColor = System.Drawing.Color.Olive
        Me.Button8.Location = New System.Drawing.Point(220, 223)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(95, 63)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Luas"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'TextBoxPanjang
        '
        Me.TextBoxPanjang.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPanjang.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxPanjang.Location = New System.Drawing.Point(220, 153)
        Me.TextBoxPanjang.Name = "TextBoxPanjang"
        Me.TextBoxPanjang.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxPanjang.TabIndex = 7
        Me.TextBoxPanjang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxKelPan
        '
        Me.TextBoxKelPan.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxKelPan.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxKelPan.Location = New System.Drawing.Point(352, 153)
        Me.TextBoxKelPan.Name = "TextBoxKelPan"
        Me.TextBoxKelPan.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxKelPan.TabIndex = 6
        Me.TextBoxKelPan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(240, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 24)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Luas"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(361, 126)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 24)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Keliling"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(15, 159)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(166, 155)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(101, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(308, 24)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Hitung Bangun Persegi Panjang"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.Purple
        Me.Button3.Location = New System.Drawing.Point(584, 176)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(123, 68)
        Me.Button3.TabIndex = 13
        Me.Button3.Text = "Hitung Segitiga"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'PanelSegitiga
        '
        Me.PanelSegitiga.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PanelSegitiga.Controls.Add(Me.TextBoxS3)
        Me.PanelSegitiga.Controls.Add(Me.Label19)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxS2)
        Me.PanelSegitiga.Controls.Add(Me.Label12)
        Me.PanelSegitiga.Controls.Add(Me.Label13)
        Me.PanelSegitiga.Controls.Add(Me.Label14)
        Me.PanelSegitiga.Controls.Add(Me.Label15)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxTinggi)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxLuasSegitiga)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxKllS)
        Me.PanelSegitiga.Controls.Add(Me.Button4)
        Me.PanelSegitiga.Controls.Add(Me.Button9)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxAlas)
        Me.PanelSegitiga.Controls.Add(Me.TextBoxS1)
        Me.PanelSegitiga.Controls.Add(Me.Label16)
        Me.PanelSegitiga.Controls.Add(Me.Label17)
        Me.PanelSegitiga.Controls.Add(Me.PictureBox3)
        Me.PanelSegitiga.Controls.Add(Me.Label18)
        Me.PanelSegitiga.Location = New System.Drawing.Point(23, 94)
        Me.PanelSegitiga.Name = "PanelSegitiga"
        Me.PanelSegitiga.Size = New System.Drawing.Size(470, 409)
        Me.PanelSegitiga.TabIndex = 18
        '
        'TextBoxS3
        '
        Me.TextBoxS3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxS3.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxS3.Location = New System.Drawing.Point(352, 217)
        Me.TextBoxS3.Name = "TextBoxS3"
        Me.TextBoxS3.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxS3.TabIndex = 19
        Me.TextBoxS3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(314, 217)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(34, 24)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "S3"
        '
        'TextBoxS2
        '
        Me.TextBoxS2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxS2.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxS2.Location = New System.Drawing.Point(352, 183)
        Me.TextBoxS2.Name = "TextBoxS2"
        Me.TextBoxS2.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxS2.TabIndex = 17
        Me.TextBoxS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(314, 186)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 24)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "S2"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(312, 153)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(34, 24)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "S1"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(180, 185)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(23, 24)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "T"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(180, 153)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(24, 24)
        Me.Label15.TabIndex = 13
        Me.Label15.Text = "A"
        '
        'TextBoxTinggi
        '
        Me.TextBoxTinggi.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTinggi.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxTinggi.Location = New System.Drawing.Point(209, 185)
        Me.TextBoxTinggi.Name = "TextBoxTinggi"
        Me.TextBoxTinggi.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxTinggi.TabIndex = 12
        Me.TextBoxTinggi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxLuasSegitiga
        '
        Me.TextBoxLuasSegitiga.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLuasSegitiga.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxLuasSegitiga.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLuasSegitiga.Location = New System.Drawing.Point(209, 289)
        Me.TextBoxLuasSegitiga.Name = "TextBoxLuasSegitiga"
        Me.TextBoxLuasSegitiga.ReadOnly = True
        Me.TextBoxLuasSegitiga.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxLuasSegitiga.TabIndex = 11
        Me.TextBoxLuasSegitiga.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxKllS
        '
        Me.TextBoxKllS.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxKllS.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxKllS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxKllS.Location = New System.Drawing.Point(352, 321)
        Me.TextBoxKllS.Name = "TextBoxKllS"
        Me.TextBoxKllS.ReadOnly = True
        Me.TextBoxKllS.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxKllS.TabIndex = 10
        Me.TextBoxKllS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(352, 252)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(95, 63)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Keliling"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.ForeColor = System.Drawing.Color.Olive
        Me.Button9.Location = New System.Drawing.Point(209, 220)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(95, 63)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "Luas"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'TextBoxAlas
        '
        Me.TextBoxAlas.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxAlas.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxAlas.Location = New System.Drawing.Point(209, 150)
        Me.TextBoxAlas.Name = "TextBoxAlas"
        Me.TextBoxAlas.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxAlas.TabIndex = 7
        Me.TextBoxAlas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxS1
        '
        Me.TextBoxS1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxS1.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxS1.Location = New System.Drawing.Point(352, 150)
        Me.TextBoxS1.Name = "TextBoxS1"
        Me.TextBoxS1.Size = New System.Drawing.Size(95, 29)
        Me.TextBoxS1.TabIndex = 6
        Me.TextBoxS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(229, 123)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 24)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Luas"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(350, 123)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(79, 24)
        Me.Label17.TabIndex = 4
        Me.Label17.Text = "Keliling"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(15, 160)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(159, 144)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(127, 48)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(230, 24)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Hitung Bangun Segitiga"
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.ForeColor = System.Drawing.Color.Brown
        Me.Button10.Location = New System.Drawing.Point(680, 15)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(90, 41)
        Me.Button10.TabIndex = 19
        Me.Button10.Text = "Keluar"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Button11.Location = New System.Drawing.Point(584, 15)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(90, 41)
        Me.Button11.TabIndex = 20
        Me.Button11.Text = "Refresh"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(800, 600)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelLingkaran)
        Me.Controls.Add(Me.PanelSegitiga)
        Me.Controls.Add(Me.PanelPersegi)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel2.ResumeLayout(False)
        Me.PanelLingkaran.ResumeLayout(False)
        Me.PanelLingkaran.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelPersegi.ResumeLayout(False)
        Me.PanelPersegi.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelSegitiga.ResumeLayout(False)
        Me.PanelSegitiga.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents PanelLingkaran As System.Windows.Forms.Panel
    Friend WithEvents LabelPhi As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBoxResVolume As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxResLuas As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents TextBoxDiameter As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxJari_Jari As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PanelPersegi As System.Windows.Forms.Panel
    Friend WithEvents TextBoxKelLel As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBoxLebar As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxLuasPerPan As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxResKel As System.Windows.Forms.TextBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents TextBoxPanjang As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxKelPan As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents PanelSegitiga As System.Windows.Forms.Panel
    Friend WithEvents TextBoxS2 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBoxTinggi As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxLuasSegitiga As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxKllS As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents TextBoxAlas As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxS1 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBoxS3 As System.Windows.Forms.TextBox
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button

End Class
