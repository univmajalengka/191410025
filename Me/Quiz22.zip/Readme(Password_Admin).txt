Untuk Password admin adalah

nama : admin
password : 1234