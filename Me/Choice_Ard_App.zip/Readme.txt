App yang Mendukung untuk Arduino Bluetooth Controller..
Pemasangan Pin,, Dapat Dilihat Di Sketsa Gambar,,
App dengan nama dht_app dapat Langsung di Instal di Android Kamu,,

Jika Memilih Di Choice,, Usahakan Untuk Ke Choice Selanjutnya Hilangkan
Dulu Ceklist di Choice Sebelumnya,,
Jika Tidak,, Sistem Tidak Akan Berjalan,,