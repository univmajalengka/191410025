App yang Mendukung untuk Arduino Bluetooth Controller..
Pemasangan Pin,, Dapat Dilihat Di Sketsa Gambar,,
App dengan nama dht_app dapat Langsung di Instal di Android Kamu,,

Jika Ada Error dengan Statement "select list item : list item index too large"
Jangan Di "End Aplication" Cukup Geser Ke Atas saja..