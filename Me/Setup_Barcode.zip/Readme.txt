New Version with Fix Bug For Camera,, Contrloing
There is Or There Isnot,,