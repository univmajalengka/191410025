Program ini support untuk Windows XP Service pak 3 dan Setelahnya,,
Karena Saya Menggunakan Sistem DotNet 3.5..

Kualitas Baca Barcode dari scanner tergantung dari Kualitas Kamera atau Gambar Yang dihasilkanya,,