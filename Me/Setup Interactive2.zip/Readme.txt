Jika Program Tidak Dapat Dijalankan,, Coba Download Terlebih Dahulu
Microsoft DotNet Framework 4.5 atau Selebihnya,,

Proses Instalasi Seperti Biasa Pada Umunya Program Melakukan Instalasi,,