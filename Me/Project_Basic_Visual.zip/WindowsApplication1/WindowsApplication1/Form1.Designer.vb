﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.PictureBoxMakanan = New System.Windows.Forms.PictureBox()
        Me.PictureBoxMinuman = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LabelTime = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ComboBoxMakanan = New System.Windows.Forms.ComboBox()
        Me.ComboBoxMinuman = New System.Windows.Forms.ComboBox()
        Me.LabelMakanan = New System.Windows.Forms.Label()
        Me.LabelHargaMakanan = New System.Windows.Forms.Label()
        Me.LabelMinuman = New System.Windows.Forms.Label()
        Me.LabelHargaMinuman = New System.Windows.Forms.Label()
        Me.TextBoxResult = New System.Windows.Forms.TextBox()
        Me.ButtonPesan = New System.Windows.Forms.Button()
        Me.TextBoxBayar = New System.Windows.Forms.TextBox()
        Me.TextBoxKembalian = New System.Windows.Forms.TextBox()
        Me.ButtonKembalian = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.PictureBoxMakanan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMinuman, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBoxMakanan
        '
        Me.PictureBoxMakanan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBoxMakanan.Location = New System.Drawing.Point(38, 162)
        Me.PictureBoxMakanan.Name = "PictureBoxMakanan"
        Me.PictureBoxMakanan.Size = New System.Drawing.Size(133, 105)
        Me.PictureBoxMakanan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxMakanan.TabIndex = 0
        Me.PictureBoxMakanan.TabStop = False
        '
        'PictureBoxMinuman
        '
        Me.PictureBoxMinuman.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBoxMinuman.Location = New System.Drawing.Point(38, 292)
        Me.PictureBoxMinuman.Name = "PictureBoxMinuman"
        Me.PictureBoxMinuman.Size = New System.Drawing.Size(133, 105)
        Me.PictureBoxMinuman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxMinuman.TabIndex = 1
        Me.PictureBoxMinuman.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Controls.Add(Me.LabelTime)
        Me.Panel1.Location = New System.Drawing.Point(-3, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(850, 69)
        Me.Panel1.TabIndex = 3
        '
        'LabelTime
        '
        Me.LabelTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTime.ForeColor = System.Drawing.Color.Navy
        Me.LabelTime.Location = New System.Drawing.Point(37, 21)
        Me.LabelTime.Name = "LabelTime"
        Me.LabelTime.Size = New System.Drawing.Size(144, 23)
        Me.LabelTime.TabIndex = 9
        Me.LabelTime.Text = "Waktu"
        Me.LabelTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SkyBlue
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Location = New System.Drawing.Point(-3, 502)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(850, 66)
        Me.Panel2.TabIndex = 4
        '
        'ComboBoxMakanan
        '
        Me.ComboBoxMakanan.FormattingEnabled = True
        Me.ComboBoxMakanan.Items.AddRange(New Object() {"Ayam Rica-Rica", "Ayam Penyet"})
        Me.ComboBoxMakanan.Location = New System.Drawing.Point(207, 162)
        Me.ComboBoxMakanan.Name = "ComboBoxMakanan"
        Me.ComboBoxMakanan.Size = New System.Drawing.Size(144, 21)
        Me.ComboBoxMakanan.TabIndex = 5
        Me.ComboBoxMakanan.Text = "Menu Makanan"
        '
        'ComboBoxMinuman
        '
        Me.ComboBoxMinuman.FormattingEnabled = True
        Me.ComboBoxMinuman.Items.AddRange(New Object() {"Jus Jeruk", "Jus Alpukat"})
        Me.ComboBoxMinuman.Location = New System.Drawing.Point(207, 292)
        Me.ComboBoxMinuman.Name = "ComboBoxMinuman"
        Me.ComboBoxMinuman.Size = New System.Drawing.Size(144, 21)
        Me.ComboBoxMinuman.TabIndex = 6
        Me.ComboBoxMinuman.Text = "Menu Minuman"
        '
        'LabelMakanan
        '
        Me.LabelMakanan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMakanan.Location = New System.Drawing.Point(207, 194)
        Me.LabelMakanan.Name = "LabelMakanan"
        Me.LabelMakanan.Size = New System.Drawing.Size(144, 23)
        Me.LabelMakanan.TabIndex = 8
        Me.LabelMakanan.Text = "Menu Makanan"
        Me.LabelMakanan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelHargaMakanan
        '
        Me.LabelHargaMakanan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelHargaMakanan.Location = New System.Drawing.Point(207, 223)
        Me.LabelHargaMakanan.Name = "LabelHargaMakanan"
        Me.LabelHargaMakanan.Size = New System.Drawing.Size(144, 23)
        Me.LabelHargaMakanan.TabIndex = 9
        Me.LabelHargaMakanan.Text = "0"
        Me.LabelHargaMakanan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelMinuman
        '
        Me.LabelMinuman.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMinuman.Location = New System.Drawing.Point(207, 323)
        Me.LabelMinuman.Name = "LabelMinuman"
        Me.LabelMinuman.Size = New System.Drawing.Size(144, 23)
        Me.LabelMinuman.TabIndex = 10
        Me.LabelMinuman.Text = "Menu Minuman"
        Me.LabelMinuman.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelHargaMinuman
        '
        Me.LabelHargaMinuman.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelHargaMinuman.Location = New System.Drawing.Point(207, 348)
        Me.LabelHargaMinuman.Name = "LabelHargaMinuman"
        Me.LabelHargaMinuman.Size = New System.Drawing.Size(144, 23)
        Me.LabelHargaMinuman.TabIndex = 11
        Me.LabelHargaMinuman.Text = "0"
        Me.LabelHargaMinuman.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxResult
        '
        Me.TextBoxResult.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBoxResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxResult.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBoxResult.Location = New System.Drawing.Point(516, 109)
        Me.TextBoxResult.Name = "TextBoxResult"
        Me.TextBoxResult.ReadOnly = True
        Me.TextBoxResult.Size = New System.Drawing.Size(281, 44)
        Me.TextBoxResult.TabIndex = 14
        Me.TextBoxResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ButtonPesan
        '
        Me.ButtonPesan.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ButtonPesan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonPesan.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ButtonPesan.Location = New System.Drawing.Point(398, 216)
        Me.ButtonPesan.Name = "ButtonPesan"
        Me.ButtonPesan.Size = New System.Drawing.Size(110, 101)
        Me.ButtonPesan.TabIndex = 15
        Me.ButtonPesan.Text = "Pesan"
        Me.ButtonPesan.UseVisualStyleBackColor = False
        '
        'TextBoxBayar
        '
        Me.TextBoxBayar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBoxBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxBayar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBoxBayar.Location = New System.Drawing.Point(562, 171)
        Me.TextBoxBayar.Name = "TextBoxBayar"
        Me.TextBoxBayar.Size = New System.Drawing.Size(235, 44)
        Me.TextBoxBayar.TabIndex = 16
        Me.TextBoxBayar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBoxKembalian
        '
        Me.TextBoxKembalian.BackColor = System.Drawing.Color.Teal
        Me.TextBoxKembalian.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxKembalian.ForeColor = System.Drawing.Color.Purple
        Me.TextBoxKembalian.Location = New System.Drawing.Point(562, 239)
        Me.TextBoxKembalian.Name = "TextBoxKembalian"
        Me.TextBoxKembalian.ReadOnly = True
        Me.TextBoxKembalian.Size = New System.Drawing.Size(235, 44)
        Me.TextBoxKembalian.TabIndex = 17
        Me.TextBoxKembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ButtonKembalian
        '
        Me.ButtonKembalian.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ButtonKembalian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonKembalian.ForeColor = System.Drawing.Color.Olive
        Me.ButtonKembalian.Location = New System.Drawing.Point(639, 305)
        Me.ButtonKembalian.Name = "ButtonKembalian"
        Me.ButtonKembalian.Size = New System.Drawing.Size(158, 75)
        Me.ButtonKembalian.TabIndex = 18
        Me.ButtonKembalian.Text = "Kembalian"
        Me.ButtonKembalian.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(724, 17)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 34)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Keluar"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Green
        Me.Button2.Location = New System.Drawing.Point(642, 17)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 34)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "Reset"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(845, 567)
        Me.Controls.Add(Me.ButtonKembalian)
        Me.Controls.Add(Me.TextBoxKembalian)
        Me.Controls.Add(Me.TextBoxBayar)
        Me.Controls.Add(Me.ButtonPesan)
        Me.Controls.Add(Me.TextBoxResult)
        Me.Controls.Add(Me.LabelHargaMinuman)
        Me.Controls.Add(Me.LabelMinuman)
        Me.Controls.Add(Me.LabelHargaMakanan)
        Me.Controls.Add(Me.LabelMakanan)
        Me.Controls.Add(Me.ComboBoxMinuman)
        Me.Controls.Add(Me.ComboBoxMakanan)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBoxMinuman)
        Me.Controls.Add(Me.PictureBoxMakanan)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.PictureBoxMakanan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMinuman, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBoxMakanan As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxMinuman As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ComboBoxMakanan As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxMinuman As System.Windows.Forms.ComboBox
    Friend WithEvents LabelMakanan As System.Windows.Forms.Label
    Friend WithEvents LabelHargaMakanan As System.Windows.Forms.Label
    Friend WithEvents LabelMinuman As System.Windows.Forms.Label
    Friend WithEvents LabelHargaMinuman As System.Windows.Forms.Label
    Friend WithEvents TextBoxResult As System.Windows.Forms.TextBox
    Friend WithEvents ButtonPesan As System.Windows.Forms.Button
    Friend WithEvents TextBoxBayar As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxKembalian As System.Windows.Forms.TextBox
    Friend WithEvents ButtonKembalian As System.Windows.Forms.Button
    Friend WithEvents LabelTime As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
