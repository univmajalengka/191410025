﻿Public Class Form1

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        LabelTime.Text = TimeOfDay
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub ComboBoxMakanan_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxMakanan.SelectedIndexChanged
        LabelMakanan.Text = ComboBoxMakanan.SelectedItem
        If ComboBoxMakanan.SelectedItem = "Ayam Rica-Rica" Then
            PictureBoxMakanan.Image = My.Resources.Ayam_Rica_Rica
            LabelHargaMakanan.Text = 15000
        ElseIf ComboBoxMakanan.SelectedItem = "Ayam Penyet" Then
            PictureBoxMakanan.Image = My.Resources.Ayam_Penyet
            LabelHargaMakanan.Text = 17000
        End If
    End Sub


    Private Sub ComboBoxMinuman_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxMinuman.SelectedIndexChanged
        LabelMinuman.Text = ComboBoxMinuman.SelectedItem
        If ComboBoxMinuman.SelectedItem = "Jus Jeruk" Then
            PictureBoxMinuman.Image = My.Resources.Jus_jeruk
            LabelHargaMinuman.Text = 5000
        ElseIf ComboBoxMinuman.SelectedItem = "Jus Alpukat" Then
            PictureBoxMinuman.Image = My.Resources.Jus_alpukat
            LabelHargaMinuman.Text = 7000
        End If
    End Sub

    Private Sub ButtonPesan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonPesan.Click
        If ComboBoxMakanan.Text = "Menu Makanan" And ComboBoxMinuman.Text = "Menu Minuman" Then
            MsgBox("Silahkan Memilih Makanan Atau Minuman Terlebih Dahulu", MsgBoxStyle.Information, "Keterangan")
        Else
            TextBoxResult.Text = Val(LabelHargaMakanan.Text) + Val(LabelHargaMinuman.Text)
        End If
    End Sub

    Private Sub ButtonKembalian_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonKembalian.Click
        Dim valr As Integer
        valr = Val(TextBoxBayar.Text) - Val(TextBoxResult.Text)
        If valr >= 0 Then
            TextBoxKembalian.Text = valr
        ElseIf TextBoxResult.Text = "" Then
            MsgBox("Kamu Belum Memesan", MsgBoxStyle.Information, "Keterangan")
        Else
            MsgBox("Uang Pembayaran Kamu Kurang" & vbNewLine & "Masukan Kembali Uang Pembayaranya", MsgBoxStyle.Information, "Keterangan")
            TextBoxBayar.Text = ""
            TextBoxBayar.Focus()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        End
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim i As New Form1
        i.Show()
        Me.Hide()
    End Sub
End Class
