﻿Public Class Form1
    Dim makanan, minuman As Integer
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TimerMakanan.Start()
        TimerMinuman.Stop()
        minuman = 0
        TextBoxListName.BackColor = Color.Yellow
        TextBoxHarga.BackColor = Color.Yellow
        TextBoxListName.ForeColor = Color.Blue
        TextBoxHarga.ForeColor = Color.Blue
    End Sub

    Private Sub TimerMakanan_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerMakanan.Tick
        makanan += 1
        If makanan = 1 Then
            PictureBoxPic.Image = My.Resources.Ayam_Penyet
            TextBoxListName.Text = "Ayam Penyet"
            TextBoxHarga.Text = 15000
        ElseIf makanan = 5 Then
            PictureBoxPic.Image = My.Resources.Ayam_Rica_Rica
            TextBoxListName.Text = "Ayam Rica-Rica"
            TextBoxHarga.Text = 18000
        ElseIf makanan = 10 Then
            makanan = 0
        End If
    End Sub

    Private Sub TimerMinuman_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerMinuman.Tick
        minuman += 1
        If minuman = 1 Then
            PictureBoxPic.Image = My.Resources.Jus_alpukat
            TextBoxListName.Text = "Jus Alpukat"
            TextBoxHarga.Text = 10000
        ElseIf minuman = 5 Then
            PictureBoxPic.Image = My.Resources.Jus_jeruk
            TextBoxListName.Text = "Jus Jeruk"
            TextBoxHarga.Text = 7000
        ElseIf minuman = 10 Then
            minuman = 0
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TimerMinuman.Start()
        TimerMakanan.Stop()
        makanan = 0
        TextBoxListName.BackColor = Color.Blue
        TextBoxHarga.BackColor = Color.Blue
        TextBoxListName.ForeColor = Color.Yellow
        TextBoxHarga.ForeColor = Color.Yellow
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBoxResList.Text = TextBoxHarga.Text
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim resKem As Integer
        resKem = Val(TextBoxBayar.Text) - Val(TextBoxResList.Text)
        If resKem <= 0 Then
            MsgBox("Nominal Uang Pembayaran Kurang", MsgBoxStyle.Information, "Keterangan")
            TextBoxBayar.Text = ""
            TextBoxBayar.Focus()
        ElseIf TextBoxBayar.Text = "" Then
            MsgBox("Kamu Belum Memaskuan Pembayaran", MsgBoxStyle.Information, "Keterangan")
            TextBoxBayar.Text = ""
            TextBoxBayar.Focus()
        Else
            TextBoxKembalian.Text = resKem
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim a As New Form1
        a.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Try
            Me.Close()
            End
        Catch ex As Exception
            Me.Close()
        End Try
    End Sub
End Class
