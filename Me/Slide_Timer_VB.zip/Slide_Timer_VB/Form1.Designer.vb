﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBoxPic = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxListName = New System.Windows.Forms.TextBox()
        Me.TextBoxHarga = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBoxResList = New System.Windows.Forms.TextBox()
        Me.TextBoxBayar = New System.Windows.Forms.TextBox()
        Me.TextBoxKembalian = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TimerMakanan = New System.Windows.Forms.Timer(Me.components)
        Me.TimerMinuman = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        CType(Me.PictureBoxPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBoxPic
        '
        Me.PictureBoxPic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBoxPic.Location = New System.Drawing.Point(16, 111)
        Me.PictureBoxPic.Name = "PictureBoxPic"
        Me.PictureBoxPic.Size = New System.Drawing.Size(451, 311)
        Me.PictureBoxPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxPic.TabIndex = 0
        Me.PictureBoxPic.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Location = New System.Drawing.Point(-2, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(885, 75)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SkyBlue
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Location = New System.Drawing.Point(-2, 494)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(885, 79)
        Me.Panel2.TabIndex = 2
        '
        'TextBoxListName
        '
        Me.TextBoxListName.BackColor = System.Drawing.Color.Yellow
        Me.TextBoxListName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxListName.ForeColor = System.Drawing.Color.Blue
        Me.TextBoxListName.Location = New System.Drawing.Point(38, 438)
        Me.TextBoxListName.Name = "TextBoxListName"
        Me.TextBoxListName.ReadOnly = True
        Me.TextBoxListName.Size = New System.Drawing.Size(218, 26)
        Me.TextBoxListName.TabIndex = 3
        Me.TextBoxListName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxHarga
        '
        Me.TextBoxHarga.BackColor = System.Drawing.Color.Yellow
        Me.TextBoxHarga.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxHarga.ForeColor = System.Drawing.Color.Blue
        Me.TextBoxHarga.Location = New System.Drawing.Point(281, 438)
        Me.TextBoxHarga.Name = "TextBoxHarga"
        Me.TextBoxHarga.ReadOnly = True
        Me.TextBoxHarga.Size = New System.Drawing.Size(140, 26)
        Me.TextBoxHarga.TabIndex = 4
        Me.TextBoxHarga.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Navy
        Me.Button1.Location = New System.Drawing.Point(474, 111)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(64, 151)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Makanan"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Olive
        Me.Button2.Location = New System.Drawing.Point(474, 268)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(63, 154)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Minuman"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TextBoxResList
        '
        Me.TextBoxResList.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBoxResList.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxResList.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxResList.Location = New System.Drawing.Point(642, 125)
        Me.TextBoxResList.Name = "TextBoxResList"
        Me.TextBoxResList.ReadOnly = True
        Me.TextBoxResList.Size = New System.Drawing.Size(218, 41)
        Me.TextBoxResList.TabIndex = 7
        Me.TextBoxResList.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBoxBayar
        '
        Me.TextBoxBayar.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxBayar.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxBayar.Location = New System.Drawing.Point(642, 195)
        Me.TextBoxBayar.Name = "TextBoxBayar"
        Me.TextBoxBayar.Size = New System.Drawing.Size(218, 41)
        Me.TextBoxBayar.TabIndex = 8
        Me.TextBoxBayar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBoxKembalian
        '
        Me.TextBoxKembalian.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TextBoxKembalian.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxKembalian.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxKembalian.Location = New System.Drawing.Point(642, 268)
        Me.TextBoxKembalian.Name = "TextBoxKembalian"
        Me.TextBoxKembalian.ReadOnly = True
        Me.TextBoxKembalian.Size = New System.Drawing.Size(218, 41)
        Me.TextBoxKembalian.TabIndex = 9
        Me.TextBoxKembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.Purple
        Me.Button3.Location = New System.Drawing.Point(544, 111)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(76, 311)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Pesan"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(739, 322)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(121, 47)
        Me.Button4.TabIndex = 11
        Me.Button4.Text = "Kembalian"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TimerMakanan
        '
        Me.TimerMakanan.Enabled = True
        Me.TimerMakanan.Interval = 150
        '
        'TimerMinuman
        '
        Me.TimerMinuman.Interval = 150
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(731, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Harga"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(731, 175)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Bayar"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(718, 249)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Kembalian"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Teal
        Me.Button5.Location = New System.Drawing.Point(689, 17)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(83, 47)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "Reset"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(779, 17)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(83, 47)
        Me.Button6.TabIndex = 16
        Me.Button6.Text = "Keluar"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(881, 573)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.TextBoxKembalian)
        Me.Controls.Add(Me.TextBoxBayar)
        Me.Controls.Add(Me.TextBoxResList)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBoxHarga)
        Me.Controls.Add(Me.TextBoxListName)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBoxPic)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.PictureBoxPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBoxPic As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TextBoxListName As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxHarga As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBoxResList As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxBayar As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxKembalian As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TimerMakanan As System.Windows.Forms.Timer
    Friend WithEvents TimerMinuman As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button

End Class
