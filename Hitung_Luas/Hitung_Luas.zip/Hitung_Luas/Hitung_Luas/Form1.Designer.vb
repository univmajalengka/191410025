﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim GradientFillColor1 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GradientFillColor2 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GaugeText1 As DevComponents.Instrumentation.GaugeText = New DevComponents.Instrumentation.GaugeText()
        Dim GaugeText2 As DevComponents.Instrumentation.GaugeText = New DevComponents.Instrumentation.GaugeText()
        Dim GaugeLinearScale1 As DevComponents.Instrumentation.GaugeLinearScale = New DevComponents.Instrumentation.GaugeLinearScale()
        Dim GaugePointer1 As DevComponents.Instrumentation.GaugePointer = New DevComponents.Instrumentation.GaugePointer()
        Dim GaugeSection1 As DevComponents.Instrumentation.GaugeSection = New DevComponents.Instrumentation.GaugeSection()
        Dim GaugeLinearScale2 As DevComponents.Instrumentation.GaugeLinearScale = New DevComponents.Instrumentation.GaugeLinearScale()
        Me.LabelBPanjang = New System.Windows.Forms.Label()
        Me.TextBoxBPanjang = New System.Windows.Forms.TextBox()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBoxBHasil = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBoxBTinggi = New System.Windows.Forms.TextBox()
        Me.TextBoxBLebar = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LabelBTinggi = New System.Windows.Forms.Label()
        Me.LabelBLebar = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBoxLuasP = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LabelSisi = New System.Windows.Forms.Label()
        Me.TextBoxSisi = New System.Windows.Forms.TextBox()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBoxHasilR = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.LabelR = New System.Windows.Forms.Label()
        Me.TextBoxR = New System.Windows.Forms.TextBox()
        Me.Guna2GroupBox4 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBoxLPP = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBoxPl = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.LabelPl = New System.Windows.Forms.Label()
        Me.LabelPp = New System.Windows.Forms.Label()
        Me.TextBoxPp = New System.Windows.Forms.TextBox()
        Me.GaugeControl2 = New DevComponents.Instrumentation.GaugeControl()
        Me.TextBoxCelsius = New System.Windows.Forms.TextBox()
        Me.TextBoxFahrenheit = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Guna2GroupBox3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Guna2GroupBox4.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.GaugeControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelBPanjang
        '
        Me.LabelBPanjang.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelBPanjang.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LabelBPanjang.Location = New System.Drawing.Point(63, 124)
        Me.LabelBPanjang.Name = "LabelBPanjang"
        Me.LabelBPanjang.Size = New System.Drawing.Size(46, 17)
        Me.LabelBPanjang.TabIndex = 0
        Me.LabelBPanjang.Text = "P"
        Me.LabelBPanjang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxBPanjang
        '
        Me.TextBoxBPanjang.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxBPanjang.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxBPanjang.Location = New System.Drawing.Point(29, 219)
        Me.TextBoxBPanjang.MaxLength = 4
        Me.TextBoxBPanjang.Name = "TextBoxBPanjang"
        Me.TextBoxBPanjang.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxBPanjang.TabIndex = 1
        Me.TextBoxBPanjang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.Teal
        Me.Guna2GroupBox1.BorderThickness = 2
        Me.Guna2GroupBox1.Controls.Add(Me.Label3)
        Me.Guna2GroupBox1.Controls.Add(Me.Label2)
        Me.Guna2GroupBox1.Controls.Add(Me.Label1)
        Me.Guna2GroupBox1.Controls.Add(Me.TextBoxBHasil)
        Me.Guna2GroupBox1.Controls.Add(Me.Button1)
        Me.Guna2GroupBox1.Controls.Add(Me.TextBoxBTinggi)
        Me.Guna2GroupBox1.Controls.Add(Me.TextBoxBLebar)
        Me.Guna2GroupBox1.Controls.Add(Me.Panel1)
        Me.Guna2GroupBox1.Controls.Add(Me.TextBoxBPanjang)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.Teal
        Me.Guna2GroupBox1.CustomBorderThickness = New System.Windows.Forms.Padding(0, 40, 0, 20)
        Me.Guna2GroupBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.Yellow
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(17, 8)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(368, 328)
        Me.Guna2GroupBox1.TabIndex = 2
        Me.Guna2GroupBox1.Text = "Hitung_Volume_Balok"
        Me.Guna2GroupBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(14, 271)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(12, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "T"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(14, 247)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(12, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "L"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(14, 222)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(12, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "P"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxBHasil
        '
        Me.TextBoxBHasil.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxBHasil.Font = New System.Drawing.Font("Segoe UI", 28.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxBHasil.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxBHasil.Location = New System.Drawing.Point(202, 226)
        Me.TextBoxBHasil.Name = "TextBoxBHasil"
        Me.TextBoxBHasil.ReadOnly = True
        Me.TextBoxBHasil.Size = New System.Drawing.Size(151, 57)
        Me.TextBoxBHasil.TabIndex = 5
        Me.TextBoxBHasil.Text = "0"
        Me.TextBoxBHasil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Teal
        Me.Button1.Location = New System.Drawing.Point(116, 219)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 73)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Volume"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TextBoxBTinggi
        '
        Me.TextBoxBTinggi.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxBTinggi.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxBTinggi.Location = New System.Drawing.Point(29, 269)
        Me.TextBoxBTinggi.MaxLength = 4
        Me.TextBoxBTinggi.Name = "TextBoxBTinggi"
        Me.TextBoxBTinggi.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxBTinggi.TabIndex = 3
        Me.TextBoxBTinggi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxBLebar
        '
        Me.TextBoxBLebar.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxBLebar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxBLebar.Location = New System.Drawing.Point(29, 244)
        Me.TextBoxBLebar.MaxLength = 4
        Me.TextBoxBLebar.Name = "TextBoxBLebar"
        Me.TextBoxBLebar.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxBLebar.TabIndex = 2
        Me.TextBoxBLebar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.LabelBTinggi)
        Me.Panel1.Controls.Add(Me.LabelBLebar)
        Me.Panel1.Controls.Add(Me.LabelBPanjang)
        Me.Panel1.Location = New System.Drawing.Point(61, 54)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(217, 155)
        Me.Panel1.TabIndex = 0
        '
        'LabelBTinggi
        '
        Me.LabelBTinggi.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelBTinggi.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LabelBTinggi.Location = New System.Drawing.Point(3, 69)
        Me.LabelBTinggi.Name = "LabelBTinggi"
        Me.LabelBTinggi.Size = New System.Drawing.Size(46, 17)
        Me.LabelBTinggi.TabIndex = 2
        Me.LabelBTinggi.Text = "T"
        Me.LabelBTinggi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelBLebar
        '
        Me.LabelBLebar.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelBLebar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LabelBLebar.Location = New System.Drawing.Point(167, 110)
        Me.LabelBLebar.Name = "LabelBLebar"
        Me.LabelBLebar.Size = New System.Drawing.Size(46, 17)
        Me.LabelBLebar.TabIndex = 1
        Me.LabelBLebar.Text = "L"
        Me.LabelBLebar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(815, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(97, 95)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.BorderColor = System.Drawing.Color.DeepSkyBlue
        Me.Guna2GroupBox2.BorderThickness = 2
        Me.Guna2GroupBox2.Controls.Add(Me.Label7)
        Me.Guna2GroupBox2.Controls.Add(Me.TextBoxLuasP)
        Me.Guna2GroupBox2.Controls.Add(Me.Button2)
        Me.Guna2GroupBox2.Controls.Add(Me.Panel2)
        Me.Guna2GroupBox2.Controls.Add(Me.TextBoxSisi)
        Me.Guna2GroupBox2.CustomBorderColor = System.Drawing.Color.DeepSkyBlue
        Me.Guna2GroupBox2.CustomBorderThickness = New System.Windows.Forms.Padding(0, 40, 0, 20)
        Me.Guna2GroupBox2.FillColor = System.Drawing.Color.LightBlue
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(17, 354)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(368, 328)
        Me.Guna2GroupBox2.TabIndex = 6
        Me.Guna2GroupBox2.Text = "Hitung_Luas_Persegi"
        Me.Guna2GroupBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(14, 245)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(12, 17)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "S"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxLuasP
        '
        Me.TextBoxLuasP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLuasP.Font = New System.Drawing.Font("Segoe UI", 28.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxLuasP.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxLuasP.Location = New System.Drawing.Point(202, 226)
        Me.TextBoxLuasP.Name = "TextBoxLuasP"
        Me.TextBoxLuasP.ReadOnly = True
        Me.TextBoxLuasP.Size = New System.Drawing.Size(151, 57)
        Me.TextBoxLuasP.TabIndex = 5
        Me.TextBoxLuasP.Text = "0"
        Me.TextBoxLuasP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(116, 219)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 73)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Luas"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.LabelSisi)
        Me.Panel2.Location = New System.Drawing.Point(106, 55)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(155, 155)
        Me.Panel2.TabIndex = 0
        '
        'LabelSisi
        '
        Me.LabelSisi.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelSisi.ForeColor = System.Drawing.Color.Aqua
        Me.LabelSisi.Location = New System.Drawing.Point(104, 68)
        Me.LabelSisi.Name = "LabelSisi"
        Me.LabelSisi.Size = New System.Drawing.Size(46, 17)
        Me.LabelSisi.TabIndex = 2
        Me.LabelSisi.Text = "S"
        Me.LabelSisi.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TextBoxSisi
        '
        Me.TextBoxSisi.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxSisi.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxSisi.Location = New System.Drawing.Point(29, 241)
        Me.TextBoxSisi.MaxLength = 4
        Me.TextBoxSisi.Name = "TextBoxSisi"
        Me.TextBoxSisi.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxSisi.TabIndex = 1
        Me.TextBoxSisi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.BorderThickness = 2
        Me.Guna2GroupBox3.Controls.Add(Me.Label8)
        Me.Guna2GroupBox3.Controls.Add(Me.TextBoxHasilR)
        Me.Guna2GroupBox3.Controls.Add(Me.Button3)
        Me.Guna2GroupBox3.Controls.Add(Me.Panel3)
        Me.Guna2GroupBox3.Controls.Add(Me.TextBoxR)
        Me.Guna2GroupBox3.CustomBorderColor = System.Drawing.Color.DarkTurquoise
        Me.Guna2GroupBox3.CustomBorderThickness = New System.Windows.Forms.Padding(0, 40, 0, 20)
        Me.Guna2GroupBox3.FillColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.Blue
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(401, 354)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.ShadowDecoration.Parent = Me.Guna2GroupBox3
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(368, 328)
        Me.Guna2GroupBox3.TabIndex = 6
        Me.Guna2GroupBox3.Text = "Hitung_Luas_Lingkaran"
        Me.Guna2GroupBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(19, 247)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(12, 17)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "r"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxHasilR
        '
        Me.TextBoxHasilR.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxHasilR.Font = New System.Drawing.Font("Segoe UI", 28.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxHasilR.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxHasilR.Location = New System.Drawing.Point(202, 226)
        Me.TextBoxHasilR.Name = "TextBoxHasilR"
        Me.TextBoxHasilR.ReadOnly = True
        Me.TextBoxHasilR.Size = New System.Drawing.Size(151, 57)
        Me.TextBoxHasilR.TabIndex = 5
        Me.TextBoxHasilR.Text = "0"
        Me.TextBoxHasilR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(116, 219)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(80, 73)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Luas"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.LabelR)
        Me.Panel3.Location = New System.Drawing.Point(61, 54)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(217, 155)
        Me.Panel3.TabIndex = 0
        '
        'LabelR
        '
        Me.LabelR.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelR.ForeColor = System.Drawing.Color.Purple
        Me.LabelR.Location = New System.Drawing.Point(127, 83)
        Me.LabelR.Name = "LabelR"
        Me.LabelR.Size = New System.Drawing.Size(49, 20)
        Me.LabelR.TabIndex = 2
        Me.LabelR.Text = "r"
        Me.LabelR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxR
        '
        Me.TextBoxR.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxR.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxR.Location = New System.Drawing.Point(34, 245)
        Me.TextBoxR.MaxLength = 4
        Me.TextBoxR.Name = "TextBoxR"
        Me.TextBoxR.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxR.TabIndex = 1
        Me.TextBoxR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Guna2GroupBox4
        '
        Me.Guna2GroupBox4.BorderThickness = 2
        Me.Guna2GroupBox4.Controls.Add(Me.Label5)
        Me.Guna2GroupBox4.Controls.Add(Me.Label6)
        Me.Guna2GroupBox4.Controls.Add(Me.TextBoxLPP)
        Me.Guna2GroupBox4.Controls.Add(Me.Button4)
        Me.Guna2GroupBox4.Controls.Add(Me.TextBoxPl)
        Me.Guna2GroupBox4.Controls.Add(Me.Panel4)
        Me.Guna2GroupBox4.Controls.Add(Me.TextBoxPp)
        Me.Guna2GroupBox4.CustomBorderColor = System.Drawing.Color.Olive
        Me.Guna2GroupBox4.CustomBorderThickness = New System.Windows.Forms.Padding(0, 40, 0, 20)
        Me.Guna2GroupBox4.FillColor = System.Drawing.Color.LightSteelBlue
        Me.Guna2GroupBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox4.ForeColor = System.Drawing.Color.Aqua
        Me.Guna2GroupBox4.Location = New System.Drawing.Point(401, 8)
        Me.Guna2GroupBox4.Name = "Guna2GroupBox4"
        Me.Guna2GroupBox4.ShadowDecoration.Parent = Me.Guna2GroupBox4
        Me.Guna2GroupBox4.Size = New System.Drawing.Size(368, 328)
        Me.Guna2GroupBox4.TabIndex = 8
        Me.Guna2GroupBox4.Text = "Hitung_Volume_Balok"
        Me.Guna2GroupBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(19, 258)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(12, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "L"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(19, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(12, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "P"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxLPP
        '
        Me.TextBoxLPP.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxLPP.Font = New System.Drawing.Font("Segoe UI", 28.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxLPP.ForeColor = System.Drawing.Color.Teal
        Me.TextBoxLPP.Location = New System.Drawing.Point(202, 226)
        Me.TextBoxLPP.Name = "TextBoxLPP"
        Me.TextBoxLPP.ReadOnly = True
        Me.TextBoxLPP.Size = New System.Drawing.Size(151, 57)
        Me.TextBoxLPP.TabIndex = 5
        Me.TextBoxLPP.Text = "0"
        Me.TextBoxLPP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.Olive
        Me.Button4.Location = New System.Drawing.Point(116, 219)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(80, 73)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Luas"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TextBoxPl
        '
        Me.TextBoxPl.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxPl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxPl.Location = New System.Drawing.Point(34, 255)
        Me.TextBoxPl.MaxLength = 4
        Me.TextBoxPl.Name = "TextBoxPl"
        Me.TextBoxPl.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxPl.TabIndex = 2
        Me.TextBoxPl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Controls.Add(Me.LabelPl)
        Me.Panel4.Controls.Add(Me.LabelPp)
        Me.Panel4.Location = New System.Drawing.Point(61, 54)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(217, 155)
        Me.Panel4.TabIndex = 0
        '
        'LabelPl
        '
        Me.LabelPl.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelPl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LabelPl.Location = New System.Drawing.Point(163, 69)
        Me.LabelPl.Name = "LabelPl"
        Me.LabelPl.Size = New System.Drawing.Size(46, 17)
        Me.LabelPl.TabIndex = 1
        Me.LabelPl.Text = "L"
        Me.LabelPl.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'LabelPp
        '
        Me.LabelPp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.LabelPp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LabelPp.Location = New System.Drawing.Point(89, 124)
        Me.LabelPp.Name = "LabelPp"
        Me.LabelPp.Size = New System.Drawing.Size(46, 17)
        Me.LabelPp.TabIndex = 0
        Me.LabelPp.Text = "P"
        Me.LabelPp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxPp
        '
        Me.TextBoxPp.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxPp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxPp.Location = New System.Drawing.Point(34, 230)
        Me.TextBoxPp.MaxLength = 4
        Me.TextBoxPp.Name = "TextBoxPp"
        Me.TextBoxPp.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxPp.TabIndex = 1
        Me.TextBoxPp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GaugeControl2
        '
        GradientFillColor1.Color1 = System.Drawing.Color.SteelBlue
        GradientFillColor1.Color2 = System.Drawing.Color.DarkGray
        Me.GaugeControl2.Frame.BackColor = GradientFillColor1
        GradientFillColor2.BorderColor = System.Drawing.Color.DeepSkyBlue
        GradientFillColor2.BorderWidth = 1
        GradientFillColor2.Color1 = System.Drawing.Color.White
        GradientFillColor2.Color2 = System.Drawing.Color.DeepSkyBlue
        Me.GaugeControl2.Frame.FrameColor = GradientFillColor2
        Me.GaugeControl2.Frame.Style = DevComponents.Instrumentation.GaugeFrameStyle.Rectangular
        GaugeText1.BackColor.BorderColor = System.Drawing.Color.Black
        GaugeText1.Location = CType(resources.GetObject("GaugeText1.Location"), System.Drawing.PointF)
        GaugeText1.Name = "Text1"
        GaugeText1.Text = "C°"
        GaugeText2.BackColor.BorderColor = System.Drawing.Color.Black
        GaugeText2.Location = CType(resources.GetObject("GaugeText2.Location"), System.Drawing.PointF)
        GaugeText2.Name = "Text2"
        GaugeText2.Text = "F°"
        Me.GaugeControl2.GaugeItems.AddRange(New DevComponents.Instrumentation.GaugeItem() {GaugeText1, GaugeText2})
        Me.GaugeControl2.LicenseKey = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F"
        GaugeLinearScale1.Labels.FormatString = "0°"
        GaugeLinearScale1.Labels.Layout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        GaugeLinearScale1.Location = CType(resources.GetObject("GaugeLinearScale1.Location"), System.Drawing.PointF)
        GaugeLinearScale1.MajorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Near
        GaugeLinearScale1.MajorTickMarks.Layout.Style = DevComponents.Instrumentation.GaugeMarkerStyle.Rectangle
        GaugeLinearScale1.MajorTickMarks.Layout.Width = 0.008!
        GaugeLinearScale1.MaxPin.Name = "MaxPin"
        GaugeLinearScale1.MaxPin.Visible = False
        GaugeLinearScale1.MinorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Near
        GaugeLinearScale1.MinorTickMarks.Layout.Width = 0.016!
        GaugeLinearScale1.MinPin.Name = "MinPin"
        GaugeLinearScale1.MinPin.Visible = False
        GaugeLinearScale1.Name = "Scale1"
        GaugeLinearScale1.Orientation = System.Windows.Forms.Orientation.Vertical
        GaugePointer1.BulbOffset = 0.026!
        GaugePointer1.BulbSize = 0.132!
        GaugePointer1.CapFillColor.BorderColor = System.Drawing.Color.DimGray
        GaugePointer1.CapFillColor.BorderWidth = 1
        GaugePointer1.CapFillColor.Color1 = System.Drawing.Color.WhiteSmoke
        GaugePointer1.CapFillColor.Color2 = System.Drawing.Color.DimGray
        GaugePointer1.FillColor.BorderColor = System.Drawing.Color.Black
        GaugePointer1.FillColor.BorderWidth = 1
        GaugePointer1.FillColor.Color1 = System.Drawing.Color.Red
        GaugePointer1.Name = "Pointer1"
        GaugePointer1.Style = DevComponents.Instrumentation.PointerStyle.Thermometer
        GaugePointer1.ThermoBackColor.Color1 = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        GaugePointer1.Value = 12.0R
        GaugePointer1.Width = 0.1!
        GaugeLinearScale1.Pointers.AddRange(New DevComponents.Instrumentation.GaugePointer() {GaugePointer1})
        GaugeSection1.FillColor.Color1 = System.Drawing.Color.SteelBlue
        GaugeSection1.FillColor.Color2 = System.Drawing.Color.LightCyan
        GaugeSection1.FillColor.GradientFillType = DevComponents.Instrumentation.GradientFillType.VerticalCenter
        GaugeSection1.Name = "Section1"
        GaugeLinearScale1.Sections.AddRange(New DevComponents.Instrumentation.GaugeSection() {GaugeSection1})
        GaugeLinearScale1.Size = New System.Drawing.SizeF(0.75!, 0.75!)
        GaugeLinearScale1.Width = 0.1!
        GaugeLinearScale2.Labels.FormatString = "0°"
        GaugeLinearScale2.Labels.Layout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        GaugeLinearScale2.Labels.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.Labels.ShowMaxLabel = False
        GaugeLinearScale2.Labels.ShowMinLabel = False
        GaugeLinearScale2.Location = CType(resources.GetObject("GaugeLinearScale2.Location"), System.Drawing.PointF)
        GaugeLinearScale2.MajorTickMarks.Interval = 20.0R
        GaugeLinearScale2.MajorTickMarks.IntervalOffset = 2.0R
        GaugeLinearScale2.MajorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.MajorTickMarks.Layout.Style = DevComponents.Instrumentation.GaugeMarkerStyle.Rectangle
        GaugeLinearScale2.MajorTickMarks.Layout.Width = 0.008!
        GaugeLinearScale2.MaxPin.Name = "MaxPin"
        GaugeLinearScale2.MaxPin.Visible = False
        GaugeLinearScale2.MaxValue = 212.0R
        GaugeLinearScale2.MinorTickMarks.Interval = 4.0R
        GaugeLinearScale2.MinorTickMarks.IntervalOffset = 2.0R
        GaugeLinearScale2.MinorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.MinorTickMarks.Layout.Width = 0.016!
        GaugeLinearScale2.MinPin.Name = "MinPin"
        GaugeLinearScale2.MinPin.Visible = False
        GaugeLinearScale2.MinValue = 32.0R
        GaugeLinearScale2.Name = "Scale2"
        GaugeLinearScale2.Orientation = System.Windows.Forms.Orientation.Vertical
        GaugeLinearScale2.Size = New System.Drawing.SizeF(0.75!, 0.75!)
        GaugeLinearScale2.Width = 0.1!
        Me.GaugeControl2.LinearScales.AddRange(New DevComponents.Instrumentation.GaugeLinearScale() {GaugeLinearScale1, GaugeLinearScale2})
        Me.GaugeControl2.Location = New System.Drawing.Point(815, 168)
        Me.GaugeControl2.Name = "GaugeControl2"
        Me.GaugeControl2.Size = New System.Drawing.Size(97, 390)
        Me.GaugeControl2.TabIndex = 10
        Me.GaugeControl2.Text = "GaugeControl2"
        '
        'TextBoxCelsius
        '
        Me.TextBoxCelsius.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBoxCelsius.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxCelsius.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxCelsius.Location = New System.Drawing.Point(826, 139)
        Me.TextBoxCelsius.MaxLength = 5
        Me.TextBoxCelsius.Name = "TextBoxCelsius"
        Me.TextBoxCelsius.ReadOnly = True
        Me.TextBoxCelsius.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxCelsius.TabIndex = 6
        Me.TextBoxCelsius.Text = "32"
        Me.TextBoxCelsius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxFahrenheit
        '
        Me.TextBoxFahrenheit.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TextBoxFahrenheit.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBoxFahrenheit.Location = New System.Drawing.Point(826, 564)
        Me.TextBoxFahrenheit.MaxLength = 4
        Me.TextBoxFahrenheit.Name = "TextBoxFahrenheit"
        Me.TextBoxFahrenheit.Size = New System.Drawing.Size(76, 23)
        Me.TextBoxFahrenheit.TabIndex = 11
        Me.TextBoxFahrenheit.Text = "0"
        Me.TextBoxFahrenheit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(812, 590)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 16)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Convert C to F"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Azure
        Me.Panel5.Location = New System.Drawing.Point(-3, 691)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(944, 29)
        Me.Panel5.TabIndex = 12
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSkyBlue
        Me.ClientSize = New System.Drawing.Size(940, 717)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBoxFahrenheit)
        Me.Controls.Add(Me.TextBoxCelsius)
        Me.Controls.Add(Me.GaugeControl2)
        Me.Controls.Add(Me.Guna2GroupBox4)
        Me.Controls.Add(Me.Guna2GroupBox3)
        Me.Controls.Add(Me.Guna2GroupBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(956, 756)
        Me.MinimumSize = New System.Drawing.Size(956, 756)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.Guna2GroupBox2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Guna2GroupBox3.ResumeLayout(False)
        Me.Guna2GroupBox3.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Guna2GroupBox4.ResumeLayout(False)
        Me.Guna2GroupBox4.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.GaugeControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelBPanjang As Label
    Friend WithEvents TextBoxBPanjang As TextBox
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents LabelBTinggi As Label
    Friend WithEvents LabelBLebar As Label
    Friend WithEvents TextBoxBHasil As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBoxBTinggi As TextBox
    Friend WithEvents TextBoxBLebar As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TextBoxLuasP As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents LabelSisi As Label
    Friend WithEvents TextBoxSisi As TextBox
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents TextBoxHasilR As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents LabelR As Label
    Friend WithEvents TextBoxR As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Guna2GroupBox4 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBoxLPP As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents TextBoxPl As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents LabelPl As Label
    Friend WithEvents LabelPp As Label
    Friend WithEvents TextBoxPp As TextBox
    Friend WithEvents GaugeControl2 As DevComponents.Instrumentation.GaugeControl
    Friend WithEvents TextBoxCelsius As TextBox
    Friend WithEvents TextBoxFahrenheit As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel5 As Panel
End Class
